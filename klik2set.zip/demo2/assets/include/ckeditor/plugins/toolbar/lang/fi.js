﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'fi', {
	toolbarCollapse: 'Kutista työkalupalkki',
	toolbarExpand: 'Laajenna työkalupalkki',
	toolbarGroups: {
		document: 'Dokumentti',
		clipboard: 'Leikepöytä/Kumoa',
		editing: 'Muokkaus',
		forms: 'Lomakkeet',
		basicstyles: 'Perustyylit',
		paragraph: 'Kappale',
		links: 'Linkit',
		insert: 'Lisää',
		styles: 'Tyylit',
		colors: 'Värit',
		tools: 'Työkalut'
	},
	toolbars: 'Editorin työkalupalkit'
} );
