﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'id', {
	toolbarCollapse: 'Ciutkan Toolbar',
	toolbarExpand: 'Bentangkan Toolbar',
	toolbarGroups: {
		document: 'Dokumen',
		clipboard: 'Papan klip / Kembalikan perlakuan',
		editing: 'Sunting',
		forms: 'Formulir',
		basicstyles: 'Gaya Dasar',
		paragraph: 'Paragraf',
		links: 'Tautan',
		insert: 'Sisip',
		styles: 'Gaya',
		colors: 'Warna',
		tools: 'Alat'
	},
	toolbars: 'Toolbar Penyunting'
} );
